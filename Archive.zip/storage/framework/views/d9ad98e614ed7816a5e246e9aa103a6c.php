<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Select Quiz To View Report
     <?php $__env->endSlot(); ?>
    <div class="container mx-auto">
        <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mt-2 mb-4 md:grid md:grid-cols-12 md:gap-4 px-4 py-4 bg-white dark:bg-gray-600 shadow-xl rounded-lg cursor-pointer ">
            <!-- Card -->
            <div class="md:col-span-2 lg:col-span-1 xl:col-span-1 flex flex-col justify-center items-center">
                <div class = "w-12 h-12 rounded-full bg-orange-400 text-white flex flex-col justify-center items-center"> <?php echo e($loop->index+1); ?> </div>
            </div>

            <div class="md:col-span-5 lg:col-span-6 xl:col-span-6 flex flex-col justify-center flex-1 min-w-64 my-2">
                <!-- Left side -->

                <div class="flex flex-col capitalize text-gray-600 px-2 mb-2">
                    <span class = "text-xs">Quiz Title</span>
                    <span class="mt-1 text-black whitespace-nowrap">
                        <?php echo e($quiz->title); ?>

                    </span>
                </div>

                <div class="flex flex-col capitalize text-gray-600 px-2 mb-2">
                    <span class = "text-xs">Quiz Description</span>
                    <span class="mt-1 text-black">
                        <?php echo e($quiz->description); ?>

                    </span>

                </div>

            </div>

            <div class="md:col-span-3 lg:col-span-2 xl:col-span-2 flex flex-col justify-center my-2">
                <!-- Middle Part -->

                <div class="my-1 capitalize text-gray-600 px-2">
                    <span class = "text-xs"> Total Marks: </span>
                    <span class="mt-1 text-black">
                        <?php echo e($quiz->max_marks); ?>

                    </span>
                </div>

                <div class="my-1 capitalize text-gray-600 px-2">
                    <span class = "text-xs">Allowed Time: </span>
                    <span class="mt-1 text-black">
                        <?php echo e($quiz->max_mins); ?> mins
                    </span>
                </div>

                <div class="my-1 capitalize text-gray-600 px-2">
                    <span class = "text-xs">Max Attempts: </span>
                    <span class="mt-1 text-black">
                        <?php echo e($quiz->attempts); ?>

                    </span>
                </div>

            </div>
            
            <div class = "md:col-span-2 lg:col-span-3 xl:col-span-3 flex flex-col justify-center">

                <div
                    class="mb-3 flex flex-col capitalize text-gray-600 px-2">
                    <span class = "text-xs block mb-2">Action</span>
                    <a href = "<?php echo e(route('admin.quizreports.individual', ['id' => $quiz->id])); ?>" class = "block text-center mb-3 px-4 py-2 bg-orange-400 text-white"> View Report </a>
                </div>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /Users/udhaiyaprasanthmahinthan/WorkFiles/Development/Projects/Websites/khinsacademy_in/resources/views/admin/reportFilter.blade.php ENDPATH**/ ?>