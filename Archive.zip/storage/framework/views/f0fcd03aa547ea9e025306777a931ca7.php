<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Score Card
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('specialClass2', null, []); ?> 
        <?php echo e(__('selectedTab')); ?>

     <?php $__env->endSlot(); ?>

    

    <div class="container mx-auto py-6">
        <?php $ans = json_decode($answers, true); ?>
        <div class = "p-3 text-white bg-orange-600 shadow mb-8">
            <h1 class = "text-xl"> You answered <?php echo e($score); ?> out of <?php echo e($questionCount); ?> questions correctly and scored <?php echo e(round($maxMarks / $questionCount * $score)); ?> / <?php echo e($maxMarks); ?> </h1>
        </div>
        <div class = "p-3 text-orange-500 bg-white shadow mb-8">
            <ul type = "none">
                <li class = "mb-2"> Name: <?php echo e(auth()->user()->name??"Details could not be fetched"); ?> </li>
                <li class = "mb-2"> Roll No: <?php echo e(auth()->user()->rollno??"N/A"); ?> </li>
            </ul>
        </div>
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ques): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class = "p-3 flex items-center bg-white shadow mb-4">
                <div class = "w-12 h-12 rounded-full bg-orange-400 text-white flex flex-col justify-center items-center mr-3"> <?php echo e($loop->index+1); ?> </div> 
                <h2 class="font-fold-text-gray-800 text-xl"> <?php echo $ques->question; ?> </h2>
            </div>
            <div class = "mb-8">
                <div class="bg-white shadow px-3 py-3 mb-3 <?php if(isset($ans[$loop->index])): ?> <?php if($ans[$loop->index] == '1'): ?> bg-orange-200 <?php endif; ?> <?php endif; ?> <?php if($ques->correct == '1'): ?> bg-green-400 <?php endif; ?>"> 1) <?php if(isset($ans[$loop->index])): ?> <?php if($ans[$loop->index] == "1"): ?> <?php echo e("Your Answer: "); ?> <?php endif; ?> <?php endif; ?> <?php echo e($ques->option1); ?> <?php if($ques->correct == "1"): ?> <?php echo e("[Correct Answer]"); ?> <?php endif; ?> </div>
                <div class="bg-white shadow px-3 py-3 mb-3 <?php if(isset($ans[$loop->index])): ?> <?php if($ans[$loop->index] == '2'): ?> bg-orange-200 <?php endif; ?> <?php endif; ?> <?php if($ques->correct == '2'): ?> bg-green-400 <?php endif; ?>"> 2) <?php if(isset($ans[$loop->index])): ?> <?php if($ans[$loop->index] == "2"): ?> <?php echo e("Your Answer: "); ?> <?php endif; ?> <?php endif; ?> <?php echo e($ques->option2); ?> <?php if($ques->correct == "2"): ?> <?php echo e("[Correct Answer]"); ?> <?php endif; ?> </div>
                <div class="bg-white shadow px-3 py-3 mb-3 <?php if(isset($ans[$loop->index])): ?> <?php if($ans[$loop->index] == '3'): ?> bg-orange-200 <?php endif; ?> <?php endif; ?> <?php if($ques->correct == '3'): ?> bg-green-400 <?php endif; ?>"> 3) <?php if(isset($ans[$loop->index])): ?> <?php if($ans[$loop->index] == "3"): ?> <?php echo e("Your Answer: "); ?> <?php endif; ?> <?php endif; ?> <?php echo e($ques->option3); ?> <?php if($ques->correct == "3"): ?> <?php echo e("[Correct Answer]"); ?> <?php endif; ?> </div>
                <div class="bg-white shadow px-3 py-3 mb-3 <?php if(isset($ans[$loop->index])): ?> <?php if($ans[$loop->index] == '4'): ?> bg-orange-200 <?php endif; ?> <?php endif; ?> <?php if($ques->correct == '4'): ?> bg-green-400 <?php endif; ?>"> 4) <?php if(isset($ans[$loop->index])): ?> <?php if($ans[$loop->index] == "4"): ?> <?php echo e("Your Answer: "); ?> <?php endif; ?> <?php endif; ?> <?php echo e($ques->option4); ?> <?php if($ques->correct == "4"): ?> <?php echo e("[Correct Answer]"); ?> <?php endif; ?> </div>
                <div class="bg-white shadow px-3 py-3 mb-3 <?php if(isset($ans[$loop->index])): ?> <?php if($ans[$loop->index] == '5'): ?> bg-orange-200 <?php endif; ?> <?php endif; ?> <?php if($ques->correct == '5'): ?> bg-green-400 <?php endif; ?>"> 5) <?php if(isset($ans[$loop->index])): ?> <?php if($ans[$loop->index] == "5"): ?> <?php echo e("Your Answer: "); ?> <?php endif; ?> <?php endif; ?> <?php echo e($ques->option5); ?> <?php if($ques->correct == "5"): ?> <?php echo e("[Correct Answer]"); ?> <?php endif; ?> </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div x-data="{open:false}" class="text-sm">
        <div x-show="open" x-cloak id="ms-answer-verify"id="ms-answer-verify">
        </div>
        <button @click="open=!open"> Show Saved Answer </button>
    </div>
    <script>
        window.addEventListener('load', function(){
            let coo = getCookie("mandraled-khins-exam-1");
            document.getElementById("ms-answer-verify").innerHTML = coo;
        });
        function getCookie(cname) {
            let name = cname + "=";
            let cookiearray = document.cookie.split(';');
            for(let i = 0; i < cookiearray.length; i++) {
                let c = cookiearray[i];
                while (c.charAt(0) == ' ') {
                c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
                }
            }
            return "";
            }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/udhaiyaprasanthmahinthan/WorkFiles/Development/Projects/Websites/khinsacademy_in/resources/views/students/quiz/scorecard.blade.php ENDPATH**/ ?>