<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Assign Quiz to Department
     <?php $__env->endSlot(); ?>
    <div class="container py-6">
        <h2 class = "text-xl font-bold mb-6"> Assigned to following departments: </h2>
        <?php $avoid = array(); ?>
        <?php $__currentLoopData = $relations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex border border-gray-400 p-3 mb-4 justify-between"> 
                <div class = "flex items-center">
                    <img class = "w-16 h-16 mr-3" src="<?php echo e($relation->icon); ?>" alt="exam-icon">
                    <h3 class = "text-lg font-bold"> <?php echo e($relation->title); ?> </h3>
                </div>
                <form action="<?php echo e(route('admin.quiz.deassign', ['dept' => $relation->department_id, 'quiz' => $relation->quiz_id ])); ?>" method = "POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <input type="submit" class = "text-lg font-semibold bg-red-500 text-white p-3" value = "x" >
                </form>
            </div>
            <?php array_push($avoid, $relation->department_id); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
        <form action="<?php echo e(route('admin.quiz.assign', ['id' => $quiz->id])); ?>" class = "mt-12" method="POST">
            <?php echo csrf_field(); ?>
            <h2 class = "text-xl font-bold mb-6"> Assign Exam to: </h2>
            <select name="addDept" id="addDept">
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(array_search($department->id, $avoid) === false): ?>
                        <option value = "<?php echo e($department->id); ?>"> <?php echo e($department->title); ?> </option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input class = "px-4 py-2 bg-orange-400" type="submit" value="Add Exam To Department">
        </form>
        
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /Users/udhaiyaprasanthmahinthan/WorkFiles/Development/Projects/Websites/khinsacademy_in/resources/views/admin/quiz/show.blade.php ENDPATH**/ ?>