<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Student Registrations
     <?php $__env->endSlot(); ?>
    <div class="container mx-auto">
        <?php if(isset($_GET['term'])): ?>
        <div class="py-3">
            <a class = "bg-gray-200 text-gray-700 px-3 py-2 border border-gray-600" href="<?php echo e(route('admin.registrations')); ?>"> &lt; Back to List Of All Students</a>
        </div>
        <?php endif; ?>
        <div class="md:flex md:justify-between md:items-center py-3">
            <p> <strong class = "text-orange-400"> <?php echo e($studentsCount); ?> </strong> students <?php echo e(isset($_GET['term']) ? "found" : "registered"); ?>. </p>
            <form class = "w-full md:w-1/2 flex" action="/student-registrations/search" method = "GET">
                <?php echo csrf_field(); ?>
                <input type="text" name = "term" class = "h-12 block flex-1 <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> px-4 py-2 mb-4 border border-gray-400 focus:ring-0 focus:border-orange-600" placeholder="Search student by roll number or name" />
                <input id = "searchBtn" type="submit" class = "h-12 bg-orange-400 hover:bg-orange-500 text-white px-2" value = "Search" />
            </form>
        </div>
        <div id = "studContainer" class="flex flex-col sm:flex-row sm:flex-wrap">
          
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="md:w-1/2 lg:w-1/3 2xl:w-1/4 p-2 mb-6 mb-4">
                    <div class="bg-white px-6 py-8 rounded-lg shadow-lg text-center h-full">
                        <div class="mb-3">
                            <?php if($student->profile_photo_path != NULL): ?>
                                <img class="w-auto mx-auto rounded-full" src="<?php echo e($student->profile_photo_path); ?>" alt="dp" />
                            <?php else: ?>
                                <img class="w-auto mx-auto rounded-full" src="https://ui-avatars.com/api/?name=<?php echo e(str_replace(".", "", str_replace(" ","+",$student->name))); ?>" alt="dp" />
                            <?php endif; ?>
                            
                        </div>
                        <h2 class="text-xl font-medium text-gray-700 mb-3 uppercase"> <?php echo e(str_replace(".", " ", $student->name)); ?> </h2>
                        <h5 class="text-sm text-orange-500 block mb-3 lowercase px-2 overflow-hidden"><?php echo e($student->email); ?></h5>
                        <span class="text-small text-gray-500 block mb-5">Joined on: <?php echo e(date('d-m-Y', strtotime($student->created_at))); ?></span>
                
                        <a href="<?php echo e(route('admin.student.show', ['id' => $student->id])); ?>" class="px-4 py-2 bg-orange-500 text-white rounded-full"> View Details </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class = "py-2">
            <?php if(isset($_GET['term'])): ?>
            <?php else: ?>
                <?php echo e($students->links()); ?>

            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH /Users/udhaiyaprasanthmahinthan/WorkFiles/Development/Projects/Websites/khinsacademy_in/resources/views/admin/registrations.blade.php ENDPATH**/ ?>