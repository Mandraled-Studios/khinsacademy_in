<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Add Questions
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('breadcrumb', null, []); ?> 
        <span> You are here: &nbsp; </span>
        <a class="inline-block pb-1 border-b border-1 border-gray-600" href="<?php echo e(route('admin.quiz.index')); ?>"> Quizzes </a> &nbsp; &gt; &nbsp; 
        <a class="inline-block pb-1 border-b border-1 border-gray-600" href="<?php echo e(route('admin.questions.index', ['slug' => $quiz->slug ])); ?>"> <?php echo e($quiz->title); ?> </a> &nbsp; &gt; &nbsp; 
        <span> <?php echo e($thisSection->name); ?> </span>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('pageincludes', null, []); ?> 
        <script src="https://polyfill.io/v3/polyfill.min.js?features=es6"></script>
        <script id="MathJax-script" src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
        <script src="https://cdn.ckeditor.com/4.16.1/standard/ckeditor.js"></script>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('pagescript', null, []); ?> 
        <script>
            CKEDITOR.replace( 'editor1' );
            CKEDITOR.replace( 'editor2' );
        </script>
     <?php $__env->endSlot(); ?>
    <div id="myForm" class = "w-3/4 p-4">
        <h3 class="text-lg mt-2 mb-6"> <?php echo e($quiz->title); ?> </h3>
        <form action="<?php echo e(route('admin.questionsInSection.store', ['id' => $quiz->id, 'section' => $thisSection->id])); ?>" method="POST" class = "p-4" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if($errors->any()): ?>
            <div class="p-3 bg-red-300 text-red-800 mb-4">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="mb-6">
                <label class = "block mb-2" for = "question_part1"> Question Part 1 </label>
                <textarea id="editor1" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" placeholder="Enter New Question" name="question_part1" required> <?php echo e(old('question_part1')); ?> </textarea>
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "quesImage"> Add an image to support the question (optional) </label>
                <input name = "quesImage" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" type="file" accept="images/*" />
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "question_part2"> Question Part 2 (Optional) </label>
                <textarea id="editor2" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" placeholder="Enter New Question" name="question_part2"> <?php echo e(old('question_part2')); ?> </textarea>
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "option1"> Option1 </label>
                <input type="text" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" placeholder="Enter Option1" name="option1" required value = "<?php echo e(old('option1')); ?>" />
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "option2"> Option2 </label>
                <input type="text" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" placeholder="Enter Option2" name="option2" required value = "<?php echo e(old('option2')); ?>" />
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "option3"> Option3 </label>
                <input type="text" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" placeholder="Enter Option3" name="option3" required value = "<?php echo e(old('option3')); ?>" />
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "option4"> Option4 (Optional) </label>
                <input type="text" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" placeholder="Enter Option4" name="option4" value = "<?php echo e(old('option4')); ?>" />
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "option5"> Option5 (Optional) </label>
                <input type="text" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" placeholder="Enter Option5" name="option5" value = "<?php echo e(old('option5')); ?>" />
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "correct_answer"> Choose the right option </label>
                <select name="correct_answer" id="correct_answer" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" required>
                    <option value="1" <?php echo e((old('correct_answer') == "1") ? "selected" : null); ?>> Option 1 </option>
                    <option value="2" <?php echo e((old('correct_answer') == "2") ? "selected" : null); ?>> Option 2 </option>
                    <option value="3" <?php echo e((old('correct_answer') == "3") ? "selected" : null); ?>> Option 3 </option>
                    <option value="4" <?php echo e((old('correct_answer') == "4") ? "selected" : null); ?>> Option 4 </option>
                    <option value="5" <?php echo e((old('correct_answer') == "5") ? "selected" : null); ?>> Option 5 </option>
                </select>
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "shuffle"> Allow Options Shuffling </label>
                <select name="shuffle" id="shuffle" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" required>
                    <option value="0" <?php echo e((old('shuffle') == "0") ? "selected" : null); ?>> No </option>
                    <option value="1" <?php echo e((old('shuffle') == "1") ? "selected" : null); ?>> Yes </option>
                </select>
            </div>
            <div class="mb-6">
                <input class = "px-4 py-2 rounded bg-green-400 text-white mt-3" type="submit" value = "Add Question" name = "submit" />
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /Users/udhaiyaprasanthmahinthan/WorkFiles/Development/Projects/Websites/khinsacademy_in/resources/views/admin/quiz/questions/createInSection.blade.php ENDPATH**/ ?>