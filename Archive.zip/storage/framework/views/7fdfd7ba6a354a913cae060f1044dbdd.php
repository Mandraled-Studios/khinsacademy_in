<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Student Profile
     <?php $__env->endSlot(); ?>
    <div class="container pt-4 py-12">
        <div class="bg-white px-6 py-8 rounded-lg shadow-lg h-full">
            <div class="mb-3">
                <?php if($student->profile_photo_path != NULL): ?>
                    <img class="w-auto rounded-full" src="<?php echo e($student->profile_photo_path); ?>" alt="dp" />
                <?php else: ?>
                    <img class="w-auto rounded-full" src="https://ui-avatars.com/api/?name=<?php echo e(str_replace(".", "", str_replace(" ","+",$student->name))); ?>" alt="dp" />
                <?php endif; ?>
                
            </div>
            <h2 class="text-xl font-medium text-gray-700 mb-3 uppercase"> <?php echo e(str_replace(".", " ", $student->name)); ?> </h2>
            <h5 class="text-sm text-orange-500 block mb-3 lowercase overflow-hidden"><?php echo e($student->email); ?></h5>
            <span class="text-small text-gray-500 block mb-5">Joined on: <?php echo e(date('d-m-Y', strtotime($student->created_at))); ?></span>
            <div class="border border-b border-gray-300"></div>
            <h3 class = "text-xl font-bold my-4"> <?php echo e($student->name); ?>'s Exam Marks </h3>
    
            <table>
                <thead>
                    <tr>
                        <th class = "uppercase p-3"> Exam Title </th>
                        <th class = "uppercase p-3"> Exam Date </th>
                        <th class = "uppercase p-3"> Score </th>
                        <th class = "uppercase p-3"> Total Marks </th>
                        <th class = "uppercase p-3"> Percentage </th>
                        <th class = "uppercase p-3"> Attempts Remaining </th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($progresses)): ?>
                        <?php $__currentLoopData = $progresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                            <tr>
                                <td class = "border border-gray-500 p-3"> <?php echo e($prog->exam->title??""); ?> </td>
                                <td class = "border border-gray-500 text-center p-3"> <?php echo e(date('d-m-Y', strtotime($prog->updated_at))); ?> </td>
                                <td class = "border border-gray-500 text-center p-3"> <?php echo e($prog->score); ?> </td>
                                <td class = "border border-gray-500 text-center p-3"> <?php echo e($prog->exam->maxMarks); ?> </td>
                                <td class = "border border-gray-500 text-center p-3"> <?php echo e(round($prog->score/$prog->exam->maxMarks * 100, 1)); ?>% </td>
                                <td class = "border border-gray-500 text-center p-3"> <?php echo e($prog->attempts_remain<=0?"0":$prog->attempts_remain); ?> </td>
                            </tr>   
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /Users/udhaiyaprasanthmahinthan/WorkFiles/Development/Projects/Websites/khinsacademy_in/resources/views/admin/studentProfile.blade.php ENDPATH**/ ?>