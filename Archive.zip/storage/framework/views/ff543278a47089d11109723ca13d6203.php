<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        All Classrooms / Batches
     <?php $__env->endSlot(); ?>
    <div class="container mx-auto py-8">
        <?php if(session()->has('success')): ?>
        <div class="p-3 mb-3 bg-green-300 text-green-800">
            <h3> <?php echo e(session('success')); ?> </h3>
        </div>
        <?php endif; ?>
        <?php if(session()->has('danger')): ?>
            <div class="p-3 mb-3 bg-red-300 text-red-800">
                <h3> <?php echo e(session('danger')); ?> </h3>
            </div>
        <?php endif; ?>
        <h3 class = "text-xl font-bold mb-4"> All Khins Academy Departments </h3>
        <div class = "flex flex-wrap mb-8"> 
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="w-24 bg-white border-2 border-gray-300 p-2 rounded-md tracking-wide shadow-lg mb-2 mr-2">
                <div class="card-header"> 
                    <img alt="icon" class="block w-full rounded-md border-2 border-gray-300 mb-2" src="<?php echo e($department->icon); ?>" />
                    <h4 class="text-sm text-center font-semibold"> <?php echo e($department->title); ?> </h4>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <h3 class = "text-xl font-bold mb-4"> Year-wise Batches </h3>

        <div class="tabs-nav flex flex-wrap">
            <ul class="flex w-48 mt-8 mb-16" id="pills-tab">
                <?php for($yr = date('Y'); $yr>=2017; $yr--): ?>
                <li class="nav-item">
                    <a class="rounded-full px-4 py-3 border" href = "#y<?php echo e($yr); ?>"><?php echo e($yr); ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </div>
        <div class = "py-4">
            <div class="tab-content" id="pills-tabContent">
                <?php for($yr = date('Y'); $yr>=2017; $yr--): ?>
                    <div class="tab-pane" id="y<?php echo e($yr); ?>">
                        <div class="md:grid md:grid-cols-12 md:gap-4">
                            <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($classroom->classYear == $yr): ?>
                                    <div class="border border-gray-600 md:col-span-4 lg:col-span-3 xl:col-span-2">
                                        <div class="p-2">
                                            <img src="<?php echo e($classroom->icon); ?>" class="w-full" alt="...">
                                            <div class="text-center mb-3">
                                                <h5 class="text-lg font-bold py-3"><?php echo e($classroom->title); ?></h5>
                                                <form action="/classrooms/<?php echo e($classroom->id); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?> 
                                                    <button type = "submit" class = "w-full p-2 rounded text-gray-200 bg-red-500 mr-2 hover:bg-red-600 text-sm" onclick="event.preventDefault();
                                                                    if(confirm('Are you sure you want to delete this classroom / batch?')){
                                                                        this.parentNode.submit();
                                                                    }"> 
                                                        Delete Class Room
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endfor; ?>
            </div>
        </div>
        <div class="mt-6 bg-gray-700 py-2 px-4 my-4 flex justify-between items-center">
            <h2 class="text-gray-200 text-xl font-bold"> Starting a new batch? </h2>
            <a href="/classrooms/create" class="bg-emerald-400 text-white hover:bg-emerald-500 px-4 py-2 rounded"> <strong> + </strong> Create New Classroom / Batch </a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /Users/udhaiyaprasanthmahinthan/WorkFiles/Development/Projects/Websites/khinsacademy_in/resources/views/admin/classrooms/index.blade.php ENDPATH**/ ?>