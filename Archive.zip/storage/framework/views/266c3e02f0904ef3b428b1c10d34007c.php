<a href="/">
    <img class="h-28" src="<?php echo e(asset('images/Khins-Logo.jpg')); ?>" />
</a>
<?php /**PATH /Users/udhaiyaprasanthmahinthan/WorkFiles/Development/Projects/Websites/khinsacademy_in/resources/views/components/authentication-card-logo.blade.php ENDPATH**/ ?>