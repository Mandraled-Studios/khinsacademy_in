<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Create Quiz
     <?php $__env->endSlot(); ?>
    <div id="myForm" class = "w-3/4 p-4">
        <form action="<?php echo e(route('admin.quiz.store')); ?>" method="POST" class = "p-4" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if($errors->any()): ?>
            <div class="p-3 bg-red-300 text-red-800 mb-4">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="mb-6">
                <label class = "block mb-2" for = "occasion_id"> Choose what occasion this quiz is for? </label>
                <select name="occasion_id" id="occasion_id" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" required>
                    <?php $__currentLoopData = $occasions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occasion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($occasion->id); ?>" <?php echo e((old('occasion_id') == $occasion->id) ? "selected" : null); ?>> <?php echo e($occasion->heading); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "title"> Title </label>
                <input type="text" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" placeholder="Enter Quiz's Title" name="title" required value = "<?php echo e(old('title')); ?>" />
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "slug"> Slug </label>
                <input type="text" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" placeholder="Enter Quiz's Slug" name="slug" required value = "<?php echo e(old('slug')); ?>" />
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "description"> Description </label>
                <textarea id = "ckeditor" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" placeholder="Enter a description for the Quiz" name="description"><?php echo e(old('description')); ?></textarea> 
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "max_marks"> Enter Maximum Marks For Quiz </label>
                <input type="number" min = "0" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" placeholder="Enter Quiz Total Marks" name="max_marks" required value = "<?php echo e(old('max_marks')); ?>" />
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "separate_marks"> Allow Separate Marks For Each Question? </label>
                <select name="separate_marks" id="separate_marks" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" required>
                    <option value="0" <?php echo e((old('separate_marks') == "0") ? "selected" : null); ?>> No </option>
                    <option value="1" <?php echo e((old('separate_marks') == "1") ? "selected" : null); ?>> Yes </option>
                </select>
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "max_mins"> Enter Maximum Time Allowed For Quiz (in minutes) </label>
                <input type="number" min = "0" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" placeholder="Enter Total Time For Quiz in Minutes" name="max_mins" required value = "<?php echo e(old('max_mins')); ?>" />
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "attempts"> Enter Maximum Attempts Allowed For Quiz </label>
                <input type="number" min = "0" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" placeholder="Enter Allowed No.Of Attempts" name="attempts" required value = "<?php echo e(old('attempts')); ?>" />
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "shuffle"> Allow Question Shuffling </label>
                <select name="shuffle" id="shuffle" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" required>
                    <option value="0" <?php echo e((old('shuffle') == "0") ? "selected" : null); ?>> No </option>
                    <option value="1" <?php echo e((old('shuffle') == "1") ? "selected" : null); ?>> Yes </option>
                </select>
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "quespdf"> Add a PDF version of questions for students to download </label>
                <input name = "quespdf" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" type="file" accept="application/pdf" />
            </div>
            <div class="mb-6">
                <label class = "block mb-2" for = "keypdf"> Add a PDF version of answer key for students to download </label>
                <input name = "keypdf" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" type="file" accept="application/pdf" />
            </div>
            <div class="mb-6">
                <input class = "px-4 py-2 rounded bg-orange-400 text-white mt-3" type="submit" value = "Save Draft" name = "save" />
                <input class = "px-4 py-2 rounded bg-green-400 text-white mt-3" type="submit" value = "Publish Quiz" name = "publish" />
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /Users/udhaiyaprasanthmahinthan/WorkFiles/Development/Projects/Websites/khinsacademy_in/resources/views/admin/quiz/create.blade.php ENDPATH**/ ?>