<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php echo e($quiz->title); ?>

     <?php $__env->endSlot(); ?>

    <div>
        <?php $__currentLoopData = $quizSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class = "bg-white p-3 border-b mb-3 ml-3 grid grid-cols-12 items-center">
                <form class="col-span-11 grid grid-cols-12 gap-1" action="<?php echo e(route('admin.quiz.sections.update', ['slug' => $quiz->slug, 'section' => $section->id])); ?>" method = "POST" class = "flex flex-1 items-center">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input class="col-span-4 border-none" type="text" name="name" id="name" value="<?php echo e($section->name); ?>">
                    <div class="col-span-3"> <span>Max Marks: </span><input name="max_marks" class = "w-full text-xl border-none flex-1 h-12 mr-2" value="<?php echo e($section->max_marks); ?>" /> </div>
                    <div class="col-span-3"> <span>Max Minutes: </span><input name="max_mins" class = "w-full text-xl border-none flex-1 h-12 mr-2" value="<?php echo e($section->max_mins); ?>" /> </div>
                    <div class="col-span-2 flex justify-end items-center"> <input type="submit" value="" class = "bg-green-600 text-white p-2 w-12 h-12 rounded-lg mr-2 edit-btn"> </div>
                </form>
                <form class="col-span-1" action="<?php echo e(route('admin.quiz.sections.destroy', ['slug' => $quiz->slug, 'section' => $section->id])); ?>" method = "POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type = "submit" class = "bg-red-600 text-white p-2 w-12 h-12 rounded-lg delete-btn" onclick="event.preventDefault();
                                            if(confirm('Are you sure you want to delete this section?')){
                                                this.parentNode.submit();
                                            }"> 
                    </button>
                </form>
            </div>
            <?php $__errorArgs = ['heading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="bg-red-300 text-red-800 p-3" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class = "w-3/4 p-4">
        <h3 class="text-lg mt-2 mb-6 font-bold"> Create Section </h3>
        <form action="<?php echo e(route('admin.quiz.sections.store', ['slug' => $quiz->slug])); ?>" method="POST" class = "p-4" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if($errors->any()): ?>
            <div class="p-3 bg-red-300 text-red-800 mb-4">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="mb-6">
                <label class = "block mb-2" for = "name"> Section Name </label>
                <input name = "name" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" type="text" />
            </div>

            <div class="mb-6">
                <label class = "block mb-2" for = "max_marks"> Max Marks </label>
                <input name = "max_marks" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" type="number" />
            </div>

            <div class="mb-6">
                <label class = "block mb-2" for = "max_mins"> Max Mins </label>
                <input name = "max_mins" class = "block px-4 py-2 mb-4 border border-gray-400 w-full focus:ring-0 focus:border-orange-600" type="number" />
            </div>
            
            <div class="mb-6">
                <input class = "px-4 py-2 rounded bg-green-400 text-white mt-3 cursor-pointer" type="submit" value = "Add Section" name = "submit" />
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /Users/udhaiyaprasanthmahinthan/WorkFiles/Development/Projects/Websites/khinsacademy_in/resources/views/admin/quiz/sections/create.blade.php ENDPATH**/ ?>