<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        All Quizzes
     <?php $__env->endSlot(); ?>

    <div class="container pt-4 py-12">

        <div class="flex justify-between my-6">
            <h3 class = "text-xl font-bold mb-4"> All Quizzes </h3>
            <a href="<?php echo e(route('admin.quiz.create')); ?>" class="px-3 py-2 bg-emerald-400 hover:bg-emerald-500 text-white"> + Add New Quiz </a>
        </div>
    
        <div class="tabs-nav">
            <ul class="flex flex-wrap my-8" id="pills-tab">
                <?php $__currentLoopData = $occasions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occasion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item my-4 mx-1">
                    <a class="rounded-full px-4 py-3 border" href = "#occ<?php echo e($occasion->id); ?>"><?php echo e($occasion->heading); ?></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div class = "py-4 mb-8">
            <div class="tab-content" id="pills-tabContent">
                <?php $__currentLoopData = $occasions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occasion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane <?php echo e($loop->index == 0 ? 'show' : ''); ?>" id="occ<?php echo e($occasion->id); ?>">
                        <?php $__currentLoopData = $occasion->quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mt-2 mb-4 md:grid md:grid-cols-12 md:gap-4 px-4 py-4 bg-white dark:bg-gray-600 shadow-xl rounded-lg cursor-pointer ">
                                <!-- Card -->
                                <div class="md:col-span-2 lg:col-span-2 xl:col-start-1 xl:col-span-1 flex flex-col justify-center items-center">
                                    <div class = "w-12 h-12 rounded-full bg-orange-400 text-white flex flex-col justify-center items-center"> <?php echo e($loop->index+1); ?> </div>
                                </div>
                    
                                <div class="md:col-span-7 xl:col-span-4 flex flex-col justify-center flex-1 min-w-64 my-2">
                                    <!-- Left side -->
                    
                                    <div class="flex flex-col capitalize text-gray-600 px-2 mb-2">
                                        <span class = "text-xs">Quiz Title</span>
                                        <span class="mt-1 text-black whitespace-nowrap">
                                            <?php echo e($quiz->title); ?>

                                        </span>
                                    </div>
                    
                                    <div class="flex flex-col capitalize text-gray-600 px-2 mb-2">
                                        <span class = "text-xs">Quiz Description</span>
                                        <span class="mt-1 text-black">
                                            <?php echo e($quiz->description); ?>

                                        </span>
                    
                                    </div>
                    
                                </div>
                    
                                <div class="md:col-span-3 xl:col-span-2 flex flex-col justify-center my-2">
                                    <!-- Middle Part -->
                    
                                    <div class="my-1 capitalize text-gray-600 px-2">
                                        <span class = "text-xs"> Total Marks: </span>
                                        <span class="mt-1 text-black">
                                            <?php echo e($quiz->max_marks); ?>

                                        </span>
                                    </div>
                    
                                    <div class="my-1 capitalize text-gray-600 px-2">
                                        <span class = "text-xs">Allowed Time: </span>
                                        <span class="mt-1 text-black">
                                            <?php echo e($quiz->max_mins); ?> mins
                                        </span>
                                    </div>
                    
                                    <div class="my-1 capitalize text-gray-600 px-2">
                                        <span class = "text-xs">Max Attempts: </span>
                                        <span class="mt-1 text-black">
                                            <?php echo e($quiz->attempts); ?>

                                        </span>
                                    </div>
                    
                                </div>
                                
                                <div class = "md:col-span-5 md:col-start-3 xl:col-span-2 xl:col-start-8 flex flex-col justify-center">
                    
                                    <div
                                        class="mb-3 flex flex-col capitalize text-gray-600 px-2">
                                        <span class = "text-xs">Quiz Status</span>
                                        <span class="mt-1 text-sm text-blueGray-400">
                                            <?php echo e($quiz->publish_status ? "Published" : "Saved In Drafts"); ?>

                                        </span>
                                        <span class="text-orange-500 text-sm">
                                            <?php echo $quiz->publish_status ? "Published Date: <br/>".date('d-m-Y', strtotime($quiz->published_at)) : "Saved Date: <br/>".date('d-m-Y', strtotime($quiz->created_at)); ?>

                                        </span>
                                    </div>
                    
                                </div>
                    
                                <div class = "md:col-span-5 xl:col-span-3 flex flex-1 flex-col justify-center">
                    
                                    <div class="mb-3 capitalize text-gray-600 px-2">
                                        <a href = "<?php echo e(route('admin.questions.index', ['slug' => $quiz->slug])); ?>" class = "block text-center mb-3 px-4 py-2 bg-orange-400 text-white"> View Questions </a>
                                        <a href = "<?php echo e(route('admin.quiz.show', ['slug' => $quiz->slug])); ?>" class = "block text-center mb-3 px-4 py-2 bg-orange-400 text-white"> Assign Exam </a>
                                        <a href = "<?php echo e(route('admin.quiz.edit', ['slug' => $quiz->slug])); ?>" class = "block text-center mb-3 px-4 py-2 bg-orange-400 text-white"> Edit Quiz </a>
                                        <form id = "deleteForm" action="<?php echo e(route('admin.quiz.destroy', ['id' => $quiz->id])); ?>" method = "POST" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?> 
                                            <button type = "submit" class = "block w-full px-4 py-2 rounded text-gray-200 bg-red-500 hover:bg-red-600" onclick="event.preventDefault();
                                                            if(confirm('Are you sure you want to delete this exam?')){
                                                                this.parentNode.submit();
                                                            }"> 
                                                Delete Exam
                                            </button>
                                        </form>
                                    </div>
                    
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /Users/udhaiyaprasanthmahinthan/WorkFiles/Development/Projects/Websites/khinsacademy_in/resources/views/admin/quiz/index.blade.php ENDPATH**/ ?>