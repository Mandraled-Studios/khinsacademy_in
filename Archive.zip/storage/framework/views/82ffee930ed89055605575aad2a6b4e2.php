<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Report
     <?php $__env->endSlot(); ?>
    <div class="container mx-auto">
        <div class = "py-4 mb-8">
            <table class = "table w-full">
                <thead class = "bg-gray-800 text-gray-100">
                    <tr>
                        <th class = "uppercase p-3"> Rank </th>
                        <th class = "uppercase p-3"> Roll Number </th>
                        <th class = "uppercase p-3"> Student Name </th>
                        <th class = "uppercase p-3"> Exam Date </th>
                        <th class = "uppercase p-3"> Right Answers </th>
                        <th class = "uppercase p-3"> Your Marks </th>
                        <th class = "uppercase p-3"> Your Percentage </th>
                        <th width="190" class = "uppercase p-3"> Attempts Remaining </th>
                    </tr>
                </thead>
                <tbody class = "border border-gray-500">
                    <?php $__currentLoopData = $progresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                        <tr>
                            <td class = "border border-gray-500 p-3"> <?php echo e($loop->iteration); ?> </td>
                            <td class = "border border-gray-500 p-3"> <?php echo e($prog->user->id??"N/A"); ?> </td>
                            <td class = "border border-gray-500 p-3"> <a href="<?php echo e(route('admin.reportsViewIndividualStudent', ['quiz' => $prog->quiz_id, 'student' => $prog->user->id])); ?>"> <?php echo e($prog->user->name??""); ?> </a> </td>
                            <td class = "border border-gray-500 text-center p-3"> <?php echo e(date('d-m-Y, h:i A', strtotime($prog->exam_date))); ?> </td>
                            <td class = "border border-gray-500 text-center p-3"> <?php echo e($prog->answered_correctly); ?> </td>
                            <td class = "border border-gray-500 text-center p-3"> <?php echo e($prog->score); ?> out of <?php echo e($quiz->max_marks); ?> </td>
                            <td class = "border border-gray-500 text-center p-3"> <?php echo e(round($prog->score/$prog->quiz->max_marks * 100)); ?>% </td>
                            <td class = "border border-gray-500 text-center p-3"> 
                                <form method="POST" action="<?php echo e(route('admin.quiz.changeStudentAttempt', ['pid' => $prog->id, 'sid' => $prog->user->id])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <div class="flex flex-wrap">
                                    <input class="w-24 flex-grow-0" type="number" name="newprogress" value="<?php echo e($prog->attempts_remain<=0?"0":$prog->attempts_remain); ?>" /> 
                                    <input class="cursor-pointer p-2 bg-green-400 text-sm" type="submit" value="Update" />
                                </div>
                                </form>
                            </td>
                        </tr>   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /Users/udhaiyaprasanthmahinthan/WorkFiles/Development/Projects/Websites/khinsacademy_in/resources/views/admin/reportFilterIndividual.blade.php ENDPATH**/ ?>