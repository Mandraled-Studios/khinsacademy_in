<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        All Departments
     <?php $__env->endSlot(); ?>
    <div class="pb-12">
        <div class="mt-6 bg-gray-700 py-2 px-4 my-4 flex justify-between items-center">
            <h2 class="text-gray-200 text-xl font-bold"> All Departments </h2>
            <a href="#create" class="bg-emerald-400 text-white hover:bg-emerald-500 px-4 py-2 rounded"> <strong> + </strong> Add New Department </a>
        </div>
        <?php if(session()->has('success')): ?>
            <div class="p-3 bg-green-300 text-green-800">
                <h3> <?php echo e(session('success')); ?> </h3>
            </div>
        <?php endif; ?>
        <?php if(session()->has('danger')): ?>
            <div class="p-3 bg-red-300 text-red-800">
                <h3> <?php echo e(session('danger')); ?> </h3>
            </div>
        <?php endif; ?>
        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class = "bg-white p-3 border-b mb-3 ml-3 flex items-center">
                <form action="<?php echo e(route('admin.departments.update', ['id' => $department->id])); ?>" method = "POST" class = "flex flex-1 items-center">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <img src="<?php echo e($department->icon); ?>" class="inline-block w-16 h-16 object-contain object-center mr-2"/>
                    <input type="text" name="title" value="<?php echo e($department->title); ?>">
                    <textarea name="description" class = "text-xl border-none flex-1 h-12 mr-2"> <?php echo e($department->description); ?> </textarea>
                    <input type="submit" value="" class = "bg-green-600 text-white p-2 w-12 h-12 rounded-lg mr-2 edit-btn">
                </form>
                <form action="<?php echo e(route('admin.departments.destroy', ['id' => $department->id])); ?>" method = "POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type = "submit" class = "bg-red-600 text-white p-2 w-12 h-12 rounded-lg delete-btn" onclick="event.preventDefault();
                                            if(confirm('Are you sure you want to delete this occasion / event ?')){
                                                this.parentNode.submit();
                                            }"> 
                    </button>
                </form>
            </div>
            <?php $__errorArgs = ['heading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="bg-red-300 text-red-800 p-3" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div id="create" class = "w-3/4 p-4">
            <h2 class = "text-xl font-bold mb-4 mt-6"> Add New Department </h2>
            <form action = "<?php echo e(route('admin.departments.store')); ?>" method = "POST" class = "mb-3" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label> New Department Name </label>
                <input type="text" name = "title" class = "<?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> block px-4 py-2 border border-gray-400 w-full focus:ring-0 focus:border-orange-600 mb-4" placeholder="Enter new department name" />
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="bg-red-300 text-red-800 p-3" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label> Department Description </label>
                <textarea name = "description" class = "<?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> block px-4 py-2 border border-gray-400 w-full focus:ring-0 focus:border-orange-600 mb-4" placeholder="Describe the new department"></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="bg-red-300 text-red-800 p-3" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label> Department Icon </label>
                <input type="file" name="icon" id="icon" class = "<?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> block px-4 py-2 border border-gray-400 w-full focus:ring-0 focus:border-orange-600 mb-4">
                <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="bg-red-300 text-red-800 p-3" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="submit" value="+ Save New Department" class = "px-4 py-2 text-white bg-orange-500">
            </form> 
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /Users/udhaiyaprasanthmahinthan/WorkFiles/Development/Projects/Websites/khinsacademy_in/resources/views/admin/departments/index.blade.php ENDPATH**/ ?>