<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Add Questions / Sections to <?php echo e($quiz->title); ?>

     <?php $__env->endSlot(); ?>
     <?php $__env->slot('breadcrumb', null, []); ?> 
        <span> You are here: &nbsp; </span>
        <a class="inline-block pb-1 border-b border-1 border-gray-600" href="<?php echo e(route('admin.quiz.index')); ?>"> Quizzes </a> &nbsp; &gt; &nbsp; 
        <span> <?php echo e($quiz->title); ?> </span>
     <?php $__env->endSlot(); ?>
    <div class = "p-4">
        <div class="container mx-auto">
            <div class="flex justify-end my-6">
                <div class="flex">
                <?php if($quiz->questions()->count() == 0 || $quiz->sections->count() > 0): ?>
                    <a href="<?php echo e(route('admin.quiz.sections.create', ['slug' => $quiz->slug])); ?>" class="flex items-center px-3 py-2 bg-orange-500 hover:bg-orange-600 text-white mr-2"> + Add New Section </a>
                <?php endif; ?>
                <?php if($quizSections->count() == 0): ?>
                    <a href="<?php echo e(route('admin.questions.create', ['slug' => $quiz->slug])); ?>" class="flex items-center px-3 py-2 bg-orange-500 hover:bg-orange-600 text-white"> + Add New Question </a>
                <?php endif; ?>
                </div>
            </div>
            <?php if($errors->any()): ?>
                <div class="p-3 bg-red-300 text-red-800 mb-4">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if($quizSections->count() > 0): ?>
                <h2 class = "text-xl font-bold mb-4 text-center md:text-left"> Sections </h2>
                <?php $__currentLoopData = $quizSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class = "bg-white p-3 border-b mb-3 ml-3 grid grid-cols-12 items-center">
                        <form class="col-span-11 grid grid-cols-12 gap-1" action="<?php echo e(route('admin.quiz.sections.update', ['slug' => $quiz->slug, 'section' => $section->id])); ?>" method = "POST" class = "flex flex-1 items-center">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input class="col-span-4 border-none" type="text" name="name" id="name" value="<?php echo e($section->name); ?>">
                            <div class="col-span-2"> <span>Max Marks: </span><input name="max_marks" class = "w-full text-xl border-none flex-1 h-12 mr-2" value="<?php echo e($section->max_marks); ?>" /> </div>
                            <div class="col-span-2"> <span>Max Minutes: </span><input name="max_mins" class = "w-full text-xl border-none flex-1 h-12 mr-2" value="<?php echo e($section->max_mins); ?>" /> </div>
                            <div class="col-span-4 flex justify-end items-center">
                                <div class="flex flex-col mr-2">
                                    <a href="<?php echo e(route('admin.questionsInSection.index', ['slug' => $quiz->slug, 'section' => $section->id])); ?>" class="flex items-center px-3 py-2 bg-orange-500 hover:bg-orange-600 text-white mb-2"> View Questions </a>
                                    <a href="<?php echo e(route('admin.questionsInSection.create', ['slug' => $quiz->slug, 'section' => $section->id])); ?>" class="flex items-center px-3 py-2 bg-orange-500 hover:bg-orange-600 text-white mb-1"> + Add Question </a>
                                </div>
                                <input type="submit" value="" class = "bg-green-600 text-white p-2 w-12 h-12 rounded-lg mr-2 edit-btn"> 
                            </div>
                        </form>
                        <form class="col-span-1" action="<?php echo e(route('admin.quiz.sections.destroy', ['slug' => $quiz->slug, 'section' => $section->id])); ?>" method = "POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type = "submit" class = "bg-red-600 text-white p-2 w-12 h-12 rounded-lg delete-btn" onclick="event.preventDefault();
                                                    if(confirm('Are you sure you want to delete this section?')){
                                                        this.parentNode.submit();
                                                    }"> 
                            </button>
                        </form>
                    </div>
                    <?php $__errorArgs = ['heading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="bg-red-300 text-red-800 p-3" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
    <div class = "w-3/4 p-4">
        <div class="container mx-auto py-8">
            <?php if($quiz->questions->count() > 0): ?>
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($question->section == null): ?>
                        <div class="p-3 border-b-2 border-gray-900 mb-4">  
                            <div class = "p-3 flex items-center bg-white shadow"> 
                                <div class = "w-12 h-12 rounded-full bg-orange-400 text-white flex flex-col justify-center items-center mr-3"> <?php echo e($loop->index+1); ?> </div> 
                                <h2 class="block text-xl font-bold flex-1 mr-3"> <?php echo $question->question_part1; ?> </h2>
                                <a href = "<?php echo e(route('admin.questions.edit', ['slug' => $quiz->slug, 'ques' => $question->id])); ?>" class = "px-4 py-2 text-white cursor-pointer bg-orange-500 hover:bg-orange-600"> Edit Question </a>
                                <form action="<?php echo e(route('admin.questions.destroy', ['id' => $quiz->id, 'ques' => $question->id])); ?>" method = "POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type = "submit" class = "bg-red-600 text-white p-2 w-12 h-12 rounded-lg delete-btn" onclick="event.preventDefault();
                                                            if(confirm('Are you sure you want to delete this question?')){
                                                                this.parentNode.submit();
                                                            }"> 
                                    </button>
                                </form>
                            </div>
                            <?php if(isset($question->quesImage)): ?>
                                <div class="bg-white shadow p-3">
                                    <img src="<?php echo e($question->quesImage); ?>" alt="" class = "w-48 h-32 object-contain object-center">
                                </div>
                            <?php endif; ?>
                            <?php if(isset($question->question_part2)): ?>
                            <div class = "py-3 pl-16 flex items-center bg-white shadow">
                                <h2 class="block text-xl font-bold flex-1 mr-3"> <?php echo $question->question_part2; ?> </h2>
                            </div>
                            <?php endif; ?>
                            <div class="mt-4 mb-4">
                                <div class="bg-white shadow p-3 mb-3 flex justify-start <?php echo e($question->correct_answer == 1 ? "bg-green-300" : null); ?>"> <label> <?php echo e($question->option1); ?> </label> </div>
                                <div class="bg-white shadow p-3 mb-3 flex justify-start <?php echo e($question->correct_answer == 2 ? "bg-green-300" : null); ?>"> <label> <?php echo e($question->option2); ?> </label> </div>
                                <div class="bg-white shadow p-3 mb-3 flex justify-start <?php echo e($question->correct_answer == 3 ? "bg-green-300" : null); ?>"> <label> <?php echo e($question->option3); ?> </label> </div>
                                <?php if(isset($question->option4)): ?>
                                    <div class="bg-white shadow p-3 mb-3 flex justify-start <?php echo e($question->correct_answer == 4 ? "bg-green-300" : null); ?>"> <label> <?php echo e($question->option4); ?> </label> </div>    
                                <?php endif; ?>
                                <?php if(isset($question->option5)): ?>
                                    <div class="bg-white shadow p-3 mb-3 flex justify-start <?php echo e($question->correct_answer == 5 ? "bg-green-300" : null); ?>"> <label> <?php echo e($question->option5); ?> </label> </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /Users/udhaiyaprasanthmahinthan/WorkFiles/Development/Projects/Websites/khinsacademy_in/resources/views/admin/quiz/questions/index.blade.php ENDPATH**/ ?>