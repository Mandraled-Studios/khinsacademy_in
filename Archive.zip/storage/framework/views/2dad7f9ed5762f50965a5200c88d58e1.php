<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        All Departments
     <?php $__env->endSlot(); ?>

    <div class="container mx-auto py-8">
        <h3 class = "text-xl font-bold mb-4 text-center md:text-left"> All Khins Academy Departments </h3>
        <div class = "flex flex-wrap justify-center md:justify-start mb-8"> 
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $found = false
            ?>
            <div class="w-40 bg-white relative border-2 border-gray-300 pb-16 rounded-md tracking-wide shadow-lg m-1">
                <div class="card-header px-2 pt-2"> 
                    <img alt="icon" class="w-full rounded-md border-2 border-gray-300 mx-auto" src="<?php echo e($department->icon); ?>" />
                    <h4 class="text-lg text-center font-semibold mt-3 mb-2"> <?php echo e($department->title); ?> </h4>
                    <?php $__currentLoopData = $deptUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $du): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($department->id == $du->id): ?>
                            <?php
                                $found = true
                            ?>
                            <?php break; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="absolute bottom-2 w-full text-center px-2">
                    <?php if($found): ?>
                        <h2 class = "text-center text-lg text-orange-400"> Joined! </h2>
                    <?php else: ?>
                        <form action="<?php echo e(route('students.departments.join')); ?>" method = "POST" class = "w-full flex flex-col items-center justify-center">
                            <?php echo csrf_field(); ?> 
                            <input type="hidden" name="department" value = "<?php echo e($department->id); ?>">
                            <input type="submit" name="join" value="Join Now" class = "block w-full text-white bg-orange-400 rounded px-4 py-2 cursor-pointer">
                        </form>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/udhaiyaprasanthmahinthan/WorkFiles/Development/Projects/Websites/khinsacademy_in/resources/views/students/departments.blade.php ENDPATH**/ ?>