<a href="/">
    <img class="h-28" src="{{asset('images/Khins-Logo.jpg')}}" />
</a>
